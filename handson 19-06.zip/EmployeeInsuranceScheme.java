package org.sachi;

import java.util.Scanner;

class Employee {
    int id;
    String name;
    String gender;
    int age;
    double salary;
    String designation;
    String insuranceScheme;

    public Employee(int id, String name, String gender, int age, double salary, String designation) {
        this.id = id;
        this.name = name;
        this.gender = gender;
        this.age = age;
        this.salary = salary;
        this.designation = designation;
        this.insuranceScheme = assignInsuranceScheme();
    }

    private String assignInsuranceScheme() {
        if (salary > 5000 && salary < 20000 && designation.equals("System Associate")) {
            return "Scheme C";
        } else if (salary >= 20000 && salary < 40000 && designation.equals("Programmer")) {
            return "Scheme B";
        } else if (salary >= 40000 && designation.equals("Manager")) {
            return "Scheme A";
        } else if (salary < 5000 && designation.equals("Clerk")) {
            return "No Scheme";
        } else {
            return "No Scheme";
        }
    }

    public void displayDetails() {
        System.out.println("\nEmployee Details:");
        System.out.println("Id: " + id);
        System.out.println("Name: " + name);
        System.out.println("Gender: " + gender);
        System.out.println("Age: " + age);
        System.out.println("Salary: " + salary);
        System.out.println("Designation: " + designation);
        System.out.println("Insurance Scheme: " + insuranceScheme);
    }
}

public class EmployeeInsuranceScheme {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Employee Id: ");
        int id = scanner.nextInt();
        scanner.nextLine();  

        System.out.print("Employee Name: ");
        String name = scanner.nextLine();

        System.out.print("Employee Gender: ");
        String gender = scanner.nextLine();

        System.out.print("Employee Age: ");
        int age = scanner.nextInt();

        System.out.print("Employee Salary: ");
        double salary = scanner.nextDouble();
        scanner.nextLine(); 

        System.out.print("Employee Designation: ");
        String designation = scanner.nextLine();

        Employee employee = new Employee(id, name, gender, age, salary, designation);
        employee.displayDetails();

        scanner.close();
    }
}
