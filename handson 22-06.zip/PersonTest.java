package JUnit;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PersonTest {

    @Test
    public void testConstructorWithValidNames() {
        Person person = new Person("John", "Doe");
        assertEquals("John", person.getFirstName());
        assertEquals("Doe", person.getLastName());
    }

    @Test
    public void testConstructorWithNullFirstName() {
        Person person = new Person(null, "Doe");
        assertNull(person.getFirstName());
        assertEquals("Doe", person.getLastName());
    }

    @Test
    public void testConstructorWithNullLastName() {
        Person person = new Person("John", null);
        assertEquals("John", person.getFirstName());
        assertNull(person.getLastName());
    }

    @Test
    public void testConstructorWithBothNamesNull() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Person(null, null);
        });
        assertEquals("Both Names Cannot be NULL", exception.getMessage());
    }

    @Test
    public void testGetFullName() {
        Person person = new Person("John", "Doe");
        assertEquals("John Doe", person.getFullName());

        person = new Person(null, "Doe");
        assertEquals("? Doe", person.getFullName());

        person = new Person("John", null);
        assertEquals("John ?", person.getFullName());

        person = new Person(null, null);
        assertEquals("? ?", person.getFullName());
    }

    @Test
    public void testGetFirstName() {
        Person person = new Person("John", "Doe");
        assertEquals("John", person.getFirstName());
    }

    @Test
    public void testGetLastName() {
        Person person = new Person("John", "Doe");
        assertEquals("Doe", person.getLastName());
    }
}

