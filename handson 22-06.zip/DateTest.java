package JUnit.Handson;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class DateTest {

    @Test
    public void testConstructor() {
        Date date = new Date(15, 8, 2023);
        assertEquals(15, date.getDay());
        assertEquals(8, date.getMonth());
        assertEquals(2023, date.getYear());
    }

    @Test
    public void testSetDay() {
        Date date = new Date(15, 8, 2023);
        date.setDay(20);
        assertEquals(20, date.getDay());
    }

    @Test
    public void testGetDay() {
        Date date = new Date(15, 8, 2023);
        assertEquals(15, date.getDay());
    }

    @Test
    public void testSetMonth() {
        Date date = new Date(15, 8, 2023);
        date.setMonth(12);
        assertEquals(12, date.getMonth());
    }

    @Test
    public void testGetMonth() {
        Date date = new Date(15, 8, 2023);
        assertEquals(8, date.getMonth());
    }

    @Test
    public void testSetYear() {
        Date date = new Date(15, 8, 2023);
        date.setYear(2025);
        assertEquals(2025, date.getYear());
    }

    @Test
    public void testGetYear() {
        Date date = new Date(15, 8, 2023);
        assertEquals(2023, date.getYear());
    }

    @Test
    public void testToString() {
        Date date = new Date(15, 8, 2023);
        assertEquals("Date is 15/8/2023", date.toString());
    }
}
