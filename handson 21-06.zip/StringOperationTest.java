package functionalinterface;

@FunctionalInterface
interface StringOperation {
    String operate(String s);
}

public class StringOperationTest {
    public static void main(String[] args) {
        // Define a lambda expression to reverse a string
        StringOperation reverseOperation = s -> new StringBuilder(s).reverse().toString();

        // Test the lambda expression by passing a string to applyOperation
        String input = "Hello, World!";
        String result = applyOperation(input, reverseOperation);

        // Print the result
        System.out.println("Original: " + input);
        System.out.println("Reversed: " + result);
    }

    // Method to apply the operation to a given string
    public static String applyOperation(String s, StringOperation operation) {
        return operation.operate(s);
    }
}
