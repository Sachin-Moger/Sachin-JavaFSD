package functionalinterface;

@FunctionalInterface
interface ArithmeticOperation {
    double operate(double a, double b);
}
    public class ArithmeticOperationsTest {
        public static void main(String[] args) {
        	
            // Define lambda expressions for each arithmetic operation
            ArithmeticOperation addition = (a, b) -> a + b;
            ArithmeticOperation subtraction = (a, b) -> a - b;
            ArithmeticOperation multiplication = (a, b) -> a * b;
            ArithmeticOperation division = (a, b) -> {
                if (b == 0) {
                    throw new ArithmeticException("Division by zero is not allowed.");
                }
                return a / b;
            };

            // Test the operations
            System.out.println("Addition of 5 and 3: " + performOperation(5, 3, addition));
            System.out.println("Subtraction of 5 and 3: " + performOperation(5, 3, subtraction));
            System.out.println("Multiplication of 5 and 3: " + performOperation(5, 3, multiplication));
            System.out.println("Division of 5 by 3: " + performOperation(5, 3, division));
        }

        // Method to perform the operation
        public static double performOperation(double a, double b, ArithmeticOperation operation) {
            return operation.operate(a, b);
        }
    }

