package org.sachin.collection;

import java.security.ProviderException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.sachin.collection.Product;

public class ProductDAO {
    private List<ProductDAO> products;

    public ProductDAO() {
        products = new ArrayList<>();
    }

    public void addProduct(ProductDAO product) {
        products.add(product);
    }

    public ProductDAO getProductById(int productId) throws ProviderException {
        for (ProductDAO product : products) {
            if (product.getProductId() == productId) {
                return product;
            }
        }
        throw new ProviderException("Product with ID " + productId + " not found.");
    }

    private int getProductId() {
		// TODO Auto-generated method stub
		return 0;
	}

	public List<ProductDAO> getAllProducts() {
        return products;
    }

    public void updateProduct(ProductDAO updatedProduct) throws ProviderException {
        ProductDAO product = getProductById(updatedProduct.getProductId());
        product.setProductName(updatedProduct.getProductName());
        product.setPrice(updatedProduct.getPrice());
        product.setQuantityInHand(updatedProduct.getQuantityInHand());
        product.setDescription(updatedProduct.getDescription());
        product.setOrderDate(updatedProduct.getOrderDate());
    }

    private void setOrderDate(Object orderDate) {
		// TODO Auto-generated method stub
		
	}

	private void setDescription(Object description) {
		// TODO Auto-generated method stub
		
	}

	private void setQuantityInHand(Object quantityInHand) {
		// TODO Auto-generated method stub
		
	}

	private Object getOrderDate() {
		// TODO Auto-generated method stub
		return null;
	}

	private Object getDescription() {
		// TODO Auto-generated method stub
		return null;
	}

	private void setPrice(Object price) {
		// TODO Auto-generated method stub
		
	}

	private Object getPrice() {
		// TODO Auto-generated method stub
		return null;
	}

	private Object getQuantityInHand() {
		// TODO Auto-generated method stub
		return null;
	}

	private void setProductName(Object productName) {
		// TODO Auto-generated method stub
		
	}

	private Object getProductName() {
		// TODO Auto-generated method stub
		return null;
	}

	public void deleteProduct(int productId) throws ProviderException {
        ProductDAO product = getProductById(productId);
        products.remove(product);
    }
}
